//
// Created by kiwul on 2/18/2021.
//

#ifndef LAB_GENERALLIB_H
#define LAB_GENERALLIB_H

int set_priority(char c);
int set_priority(char c);
int is_operand(char c);
int is_higher_or_eq(char one, char two);
void add_char_to_str(char c, char* str, int len);


#endif //LAB_GENERALLIB_H
